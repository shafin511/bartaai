import { GoogleGenAI } from '@google/genai';
import { GEMINI_IMAGE_MODEL } from '../constants';

/**
 * Converts a File object to a GoogleGenerativeAI.Part object for image input.
 * @param file The image file.
 * @param mimeType The MIME type of the image.
 * @returns A Promise resolving to a GenerativePart.
 */
export async function fileToGenerativePart(file: File, mimeType: string): Promise<{ inlineData: { data: string; mimeType: string; }; }> {
  const base64EncodedDataPromise = new Promise<string>((resolve) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
    reader.readAsDataURL(file);
  });
  const base64EncodedData = await base64EncodedDataPromise;
  return {
    inlineData: {
      data: base64EncodedData,
      mimeType,
    },
  };
}

/**
 * Generates an image from a text prompt using the Gemini API.
 * @param prompt The text prompt for image generation.
 * @param apiKey The Google AI API Key.
 * @returns A Promise resolving to the base64 encoded image string.
 * @throws Error if image generation fails or API key is invalid.
 */
export const generateImageFromPromptService = async (prompt: string, apiKey: string): Promise<string> => {
  if (!apiKey) {
    throw new Error("API Key is required for image generation.");
  }
  const ai = new GoogleGenAI({ apiKey });
  
  try {
    const response = await ai.models.generateImages({
        model: GEMINI_IMAGE_MODEL,
        prompt: prompt,
        config: { numberOfImages: 1, outputMimeType: 'image/jpeg' }, // or image/png
    });

    if (response.generatedImages && response.generatedImages.length > 0 && response.generatedImages[0].image.imageBytes) {
      return response.generatedImages[0].image.imageBytes; // This is already base64 encoded string
    } else {
      throw new Error("No image generated or image data is missing.");
    }
  } catch (error: any) {
    console.error("Gemini Image Generation Error:", error);
    if (error.message && error.message.includes('API key not valid')) {
        throw new Error("API Key is not valid for image generation.");
    }
    throw new Error("Failed to generate image: " + (error.message || "Unknown error"));
  }
};