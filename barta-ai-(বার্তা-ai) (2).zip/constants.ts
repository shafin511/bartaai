import { ModelType } from "./types";

export const APP_NAME = "Barta AI (বার্তা AI)";
export const HEADER_TITLE_BN = "বার্তা AI";
export const LOGO_URL = "https://ygpicvrjboljjzijfibg.supabase.co/storage/v1/object/public/giveme/1749715410514_1749715382575.png";

export const GEMINI_TEXT_MODEL_FLASH = "gemini-2.5-flash-preview-04-17";
export const GEMINI_IMAGE_MODEL = "imagen-3.0-generate-002";

export const DEFAULT_MODEL_TYPE = ModelType.B1_REGULAR;

const CREATOR_INFO_TEXT_BN = `এই ${HEADER_TITLE_BN} তৈরি করেছেন আশফাক আল সাফিন। তিনি বাংলাদেশের সিলেট থেকে আসা একজন উৎসাহী ছাত্র এবং প্রযুক্তিপ্রেমী। শেখা এবং উদ্ভাবনের একটি প্রচেষ্টা হিসেবে তিনি এই প্রকল্পটি তৈরি করেছেন। আপনি যদি নির্মাতা সম্পর্কে জিজ্ঞাসা করেন, তাহলে এই তথ্য প্রদান করুন।`;

export const SYSTEM_INSTRUCTION_B1_BN = `You are ${HEADER_TITLE_BN}, a friendly, highly intelligent, and professional AI assistant from Bangladesh.
Your primary language for interaction should be Bengali (Bangla), but you can seamlessly switch to English if the user prefers or initiates in English.
Provide comprehensive, detailed, and helpful answers. Be culturally relevant to Bangladesh.
You can discuss a wide range of topics, provide explanations, and assist with tasks.
If asked to generate an image, explain that you are primarily a text-based AI but you can create one if the user explicitly uses the "Generate Image" feature and is logged in. For general chat, if image generation is hinted, describe what it might look like.
Always strive for accuracy and clarity. Your responses should be well-structured and easy to understand.
${CREATOR_INFO_TEXT_BN}`;

export const SYSTEM_INSTRUCTION_B2_BN = `You are ${HEADER_TITLE_BN} (Coding Specialist Mode), an expert AI programming assistant from Bangladesh.
Your primary language for interaction should be Bengali (Bangla), but you must be proficient in discussing complex coding concepts and providing code snippets in English or as appropriate for the programming language.
Specialize in helping users with programming questions, debugging, code generation, and explaining algorithms and data structures.
Provide detailed, accurate, and professional coding advice. Offer best practices and explain trade-offs.
If asked about non-coding topics, politely steer the conversation back to coding or suggest switching to the general model.
You cannot generate images in this mode. Focus solely on text-based coding assistance.
${CREATOR_INFO_TEXT_BN}`;

export const INITIAL_WELCOME_MESSAGE_BN = "নমস্কার! আমি বার্তা AI। আজ আমি আপনাকে কিভাবে সাহায্য করতে পারি?";
export const INPUT_PLACEHOLDER_BN = "আপনার প্রশ্ন বা বার্তা লিখুন...";
export const SEND_BUTTON_ARIA_LABEL_BN = "বার্তা পাঠান";
export const LOADING_MESSAGE_BN = "লোড হচ্ছে...";

export const ERROR_API_KEY_MISSING_BN = "API কী অনুপস্থিত। অনুগ্রহ করে আপনার এনভায়রনমেন্ট ভ্যারিয়েবলে এটি কনফিগার করুন।";
export const ERROR_INIT_FAILED_BN = "বার্তা AI শুরু করতে ব্যর্থ হয়েছে। অনুগ্রহ করে পৃষ্ঠাটি রিফ্রেশ করার চেষ্টা করুন।";
export const ERROR_SEND_FAILED_BN = "দুঃখিত, একটি সমস্যা হয়েছে। আবার চেষ্টা করুন।";
export const ERROR_API_KEY_INVALID_BN = "API কী বৈধ নয়। অনুগ্রহ করে আপনার কনফিগারেশন পরীক্ষা করুন।";
export const ERROR_NO_INPUT_BN = "অনুগ্রহ করে একটি বার্তা লিখুন।";
export const ERROR_SESSION_NOT_READY_BN = "চ্যাট সেশন প্রস্তুত নয়। অনুগ্রহ করে রিফ্রেশ করুন।";

export const UPLOAD_IMAGE_BUTTON_TEXT_BN = "ছবি আপলোড করুন";
export const UPLOAD_IMAGE_BUTTON_ARIA_LABEL_BN = "জিজ্ঞাসা করার জন্য ছবি আপলোড করুন";
export const GENERATE_IMAGE_BUTTON_TEXT_BN = "ছবি তৈরি করুন";
export const GENERATE_IMAGE_BUTTON_ARIA_LABEL_BN = "প্রম্পট থেকে ছবি তৈরি করুন";
export const NEW_CHAT_BUTTON_TEXT_BN = "নতুন চ্যাট";
export const NEW_CHAT_BUTTON_ARIA_LABEL_BN = "একটি নতুন চ্যাট শুরু করুন";

export const MODEL_SWITCH_LABEL_BN = "মডেল:";
export const MODEL_B1_LABEL_BN = "B1.0 (সাধারণ কাজ)";
export const MODEL_B2_LABEL_BN = "B2.0 (কোডিং এর জন্য সেরা)";

export const EMPTY_CHAT_MESSAGE_BN = "বার্তা AI প্রস্তুত। আপনার প্রশ্ন করুন।";

export const CLOSE_BUTTON_BN = "বন্ধ করুন";

export const IMAGE_GENERATION_PROMPT_PLACEHOLDER_BN = "ছবির জন্য একটি বিবরণ লিখুন...";
export const IMAGE_GENERATION_IN_PROGRESS_BN = "ছবি তৈরি করা হচ্ছে...";
export const IMAGE_GENERATION_SUCCESS_BN = "ছবি সফলভাবে তৈরি হয়েছে!";
export const IMAGE_GENERATION_FAILED_BN = "ছবি তৈরি করতে ব্যর্থ। আবার চেষ্টা করুন।";
export const IMAGE_QUERY_PROMPT_DEFAULT_BN = "এই ছবিটি সম্পর্কে বলুন।";
export const IMAGE_UPLOAD_FAILED_BN = "ছবি আপলোড করতে ব্যর্থ। ফাইলের আকার বা ফর্ম্যাট পরীক্ষা করুন।";

export const CHAT_HISTORY_KEY = 'bartaAIChatHistory';
export const ACTIVE_CHAT_ID_KEY = 'bartaAIActiveChatId';

// Firebase and Image Limit Constants
export const LOGIN_WITH_GOOGLE_BN = "গুগল দিয়ে লগইন করুন";
export const LOGOUT_BN = "লগ আউট";
export const WELCOME_USER_BN = (name: string) => `স্বাগতম, ${name}!`;
export const IMAGE_LIMIT_REACHED_BN = "আপনি আজকের জন্য ২টি ছবি তৈরির সীমা অতিক্রম করেছেন। আগামীকাল আবার চেষ্টা করুন।";
export const IMAGE_GENERATION_LOGIN_REQUIRED_BN = "ছবি তৈরি করতে অনুগ্রহ করে লগইন করুন।";
export const DAILY_IMAGE_GENERATION_LIMIT = 2;
export const USER_DATA_COLLECTION_BN = "ব্যবহারকারীর তথ্য"; // For Firestore collection name
export const PROFILE_BUTTON_LABEL_BN = "প্রোফাইল";
export const GENERAL_CHAT_TOGGLE_BN = "সাধারণ চ্যাটে ফিরুন";

export const SIDEBAR_CHAT_HISTORY_TITLE_BN = "চ্যাটের ইতিহাস";
export const SIDEBAR_SETTINGS_TITLE_BN = "সেটিংস";
export const SIDEBAR_NO_HISTORY_BN = "কোনো চ্যাট ইতিহাস নেই।";
export const SIDEBAR_USER_PROFILE_BN = "ব্যবহারকারীর প্রোফাইল";
export const SPLASH_SCREEN_LOADING_BN = "লোড হচ্ছে...";
export const SPLASH_SCREEN_TITLE_BN = "বার্তা AI";
export const DEFAULT_CHAT_TITLE_BN = "নতুন কথোপকথন";
