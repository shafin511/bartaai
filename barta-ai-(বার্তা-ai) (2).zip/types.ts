import { User as OriginalFirebaseUser } from 'firebase/auth'; // Renaming to avoid conflict if any local User type exists
import { Timestamp } from 'firebase/firestore';

export enum Sender {
  User = 'user',
  AI = 'ai',
}

export enum ModelType {
  B1_REGULAR = "gemini-2.5-flash-preview-04-17",
  B2_CODING = "gemini-2.5-flash-preview-04-17",
}

export interface ChatMessage {
  id: string;
  text: string;
  sender: Sender;
  timestamp: Date;
  imageUrl?: string; 
  isImageQuery?: boolean; 
  generatedImage?: string; 
  modelUsed?: ModelType; 
}

export interface ChatSession {
  id: string;
  title: string; 
  messages: ChatMessage[];
  model: ModelType;
  timestamp: Date;
  systemInstruction: string;
}

// Use the imported FirebaseUser type
export type User = OriginalFirebaseUser | null;

export interface UserImageGenerationData {
  count: number;
  lastGeneratedAt: Timestamp; // Firebase Timestamp for accurate server-side time comparison
}