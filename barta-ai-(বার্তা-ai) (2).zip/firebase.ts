import { initializeApp } from 'firebase/app';
import { 
  getAuth, 
  GoogleAuthProvider, 
  signInWithPopup, 
  signOut as firebaseSignOut, 
  onAuthStateChanged,
  User as FirebaseUser // Import User type from firebase/auth
} from 'firebase/auth';
import { 
  getFirestore, 
  doc, 
  getDoc, 
  setDoc, 
  serverTimestamp, 
  Timestamp 
} from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyAN0E68O3RwCTAHO9mV6cLhqeKUd21pNcM",
  authDomain: "thumvio.firebaseapp.com",
  databaseURL: "https://thumvio-default-rtdb.firebaseio.com",
  projectId: "thumvio",
  storageBucket: "thumvio.firebasestorage.app",
  messagingSenderId: "462340608288",
  appId: "1:462340608288:web:9ee64f711cdcc61f8c4745",
  measurementId: "G-D29FWGCWFF"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const firestore = getFirestore(app);
const googleProvider = new GoogleAuthProvider();

export { 
  auth, 
  firestore, 
  googleProvider, 
  signInWithPopup, 
  firebaseSignOut, 
  onAuthStateChanged, 
  doc, 
  getDoc, 
  setDoc, 
  serverTimestamp, 
  Timestamp 
};
export type { FirebaseUser }; // Export FirebaseUser type